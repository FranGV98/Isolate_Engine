# Isolate Engine

Isolate Engine is a Game Engine developed by two men that work hard with dumbbels and keyboard.

## Members
**Guillem Turmo** https://github.com/Turmo11

**Fran Guerrero** https://github.com/FranGV98

## How it works
Camera Control:
- F to focus in a selected gameobject
- ALT + RIGHTCLICK and move to orbit around the selected gameobject
- Press WHEELMOUSEBUTTON to scroll the camera in x and y axis.
- Use the wheel to zoom in or zoom out.
- SHIFT duplicates movement speed

Comments to the teacher:
- If you want to select any GameObject from the hierarchy window, in case this GameObject has any children, you have to unfold the parent first and then you can select the object to view its propierties on the inspector.

- We weren't able to make the TextureComponent work in time, therefore we took it out of the release and manually Loaded the Baker House texture so you can see it can display them

- We are aware that the project structure it's a bit messy, we'll try to massively improve that for the next delivery

